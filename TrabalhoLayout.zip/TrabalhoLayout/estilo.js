function login() {

    var nome = document.getElementById("nomeid");

    if (nome.value != "") {
        alert('Seja Bem Vindo à Biblioteca Mundo das Traças, Sr(a) ' + nome.value + '!');
    }

}